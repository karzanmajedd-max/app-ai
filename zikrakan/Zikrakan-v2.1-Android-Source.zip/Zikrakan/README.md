# زیکرەکان — کارتی زیکر لەسەر شاشە (Overlay) + Heads-up

## چۆن APK دروست بکەیت
1. **Android Studio** (Koala یان نوێتر) بکەرەوە ← `Open` ← فۆلدەری `Zikrakan`.
2. ڕێگە بدە Gradle Sync تەواو ببێت (ئینتەرنێت پێویستە).
3. `Build ← Build Bundle(s)/APK(s) ← Build APK(s)`.
4. APK ـەکە لێرە دەبێت: `app/build/outputs/apk/debug/app-debug.apk`

> ئەگەر ئەپە کۆنەکە (`com.zikr.zikrakan`) دامەزراوە و واژۆی جیاوازە، سەرەتا بیسڕەوە.

## شێوازی کارکردن
- ئەگەر «Display over other apps» ڕێگەپێدراو بێت: کارتی زیکر لەسەر هەموو ئەپەکان دەردەکەوێت و بە **دەست لێدان دادەخرێت** (دوای ١ خولەک خۆشی دادەخرێت).
- ئەگەر ڕێگەپێدراو نەبێت: نۆتیکیشنی Heads-up ی ئاسایی.
- لە Oppo/Realme/Xiaomi: لە ڕێکخستنی ئەپەکە **Display over other apps** و **Floating windows / Pop-ups** چالاک بکە.

## ئەوەی گۆڕدرا
- `index.html` — تەنیا ٤ گۆڕانکاری بچووک: ڕێکخستنەکان دەنێردرێن بۆ Kotlin (`Android.savePrefs`)، دوگمەی «نموونە» نۆتیکیشنی ڕاستەقینە پیشان دەدات، و نۆتیکیشنی ساختەی ناو ئەپەکە ناچالاک دەبێت.
- `dhikr.json` — ١٧ زیکرەکە (هەمان ناوەڕۆکی index.html).
- `Scheduler.kt` — کاتی داهاتوو دەژمێرێت (هەر چەند خولەک / کاتە دیاریکراوەکان) و `AlarmManager` ڕێکدەخات.
- `Overlay.kt` — کارتی زیکر لەسەر شاشە (WindowManager، `TYPE_APPLICATION_OVERLAY`).
- `Notifier.kt` — نۆتیکیشنی `IMPORTANCE_HIGH` (Heads-up)، دەنگ و لەرزین بە گوێرەی ڕێکخستن.
- `BootReceiver.kt` — دوای ڕیستارت ئالارمەکان دووبارە دادەنێت.

## گرنگ لەسەر مۆبایلە چینییەکان (Xiaomi / Oppo / Vivo / Samsung)
لە ڕێکخستنی ئەپەکە:
- **Notifications ← Floating / Pop-up notifications** چالاک بکە
- **Autostart** چالاک بکە
- **Battery ← No restrictions**

بەبێ ئەمانە سیستەم دەتوانێت ئالارمەکان ڕابگرێت یان بانەرەکە پیشان نەدات.
