package com.zikr.zikrakan

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/** کاتی نۆتیکیشنی داهاتوو دیاری دەکات و AlarmManager ڕێکدەخات */
object Scheduler {
    private const val REQ = 1001
    private val HM = Regex("^(\\d{1,2}):(\\d{2})$")

    private fun normalizeDigits(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            when (ch) {
                in '\u0660'..'\u0669' -> sb.append('0' + (ch - '\u0660'))
                in '\u06F0'..'\u06F9' -> sb.append('0' + (ch - '\u06F0'))
                '\uFF1A' -> sb.append(':')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun toMin(raw: String): Int? {
        val m = HM.find(normalizeDigits(raw.trim())) ?: return null
        val h = m.groupValues[1].toInt()
        val mi = m.groupValues[2].toInt()
        return if (h in 0..23 && mi in 0..59) h * 60 + mi else null
    }

    /** هەموو خولەکەکانی ڕۆژ (٠–١٤٣٩) کە نۆتیکیشنیان تێدا دەنێردرێت */
    fun slots(p: ZikrPrefs): List<Int> {
        if (p.mode == "interval") {
            val s = toMin(p.start)
            val e = toMin(p.end)
            val step = p.interval
            if (s == null || e == null || step < 1) return emptyList()
            val out = ArrayList<Int>()
            var m = s
            while (m <= e) {
                out.add(m)
                m += step
            }
            return out
        }
        return p.times.split(Regex("[,\u060C\\n;]+"))
            .mapNotNull { toMin(it) }
            .distinct()
            .sorted()
    }

    fun nextTriggerMillis(p: ZikrPrefs, now: Calendar = Calendar.getInstance()): Long? {
        val list = slots(p)
        if (list.isEmpty()) return null
        val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val c = now.clone() as Calendar
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        var target = list.firstOrNull { it > nowMin }
        if (target == null) {
            c.add(Calendar.DAY_OF_YEAR, 1)
            target = list.first()
        }
        c.set(Calendar.HOUR_OF_DAY, target / 60)
        c.set(Calendar.MINUTE, target % 60)
        return c.timeInMillis
    }

    private fun pendingIntent(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, REQ, Intent(ctx, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun canExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        return ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    }

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pendingIntent(ctx)
        am.cancel(pi)
        val p = ZikrPrefs.load(ctx)
        if (!p.enabled) return
        val t = nextTriggerMillis(p) ?: return
        if (canExact(ctx)) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        }
    }
}
