package com.zikr.zikrakan

import android.content.Context
import org.json.JSONObject

/** ڕێکخستنەکانی بەکارهێنەر — هەمان ئەوەی لە index.html دەنێردرێت */
data class ZikrPrefs(
    val enabled: Boolean = true,
    val sound: Boolean = false,
    val vibrate: Boolean = true,
    val mode: String = "interval",
    val interval: Int = 45,
    val start: String = "07:00",
    val end: String = "22:00",
    val times: String = "08:00, 12:00, 18:00"
) {
    companion object {
        private const val FILE = "zikr_native"
        private const val KEY = "prefs_json"

        fun load(ctx: Context): ZikrPrefs {
            val raw = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, null)
            return if (raw == null) ZikrPrefs() else parse(raw)
        }

        fun saveRaw(ctx: Context, raw: String) {
            ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, raw).apply()
        }

        fun parse(raw: String): ZikrPrefs = try {
            val o = JSONObject(raw)
            val d = ZikrPrefs()
            ZikrPrefs(
                enabled = o.optBoolean("enabled", d.enabled),
                sound = o.optBoolean("sound", d.sound),
                vibrate = o.optBoolean("vibrate", d.vibrate),
                mode = o.optString("mode", d.mode),
                interval = o.optInt("interval", d.interval),
                start = o.optString("start", d.start),
                end = o.optString("end", d.end),
                times = o.optString("times", d.times)
            )
        } catch (e: Exception) {
            ZikrPrefs()
        }
    }
}
