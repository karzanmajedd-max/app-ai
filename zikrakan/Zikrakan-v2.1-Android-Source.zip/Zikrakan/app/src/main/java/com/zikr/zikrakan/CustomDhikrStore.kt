package com.zikr.zikrakan

import android.content.Context
import org.json.JSONArray

/** Persistent user-authored dhikr used by BOTH the WebView list and background alarms. */
object CustomDhikrStore {
    private const val FILE = "zikr_custom_dhikr"
    private const val KEY = "items"
    private const val MAX_ITEMS = 500

    fun raw(ctx: Context): String =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"

    fun load(ctx: Context): List<Notifier.Dhikr> = try {
        val list = JSONArray(raw(ctx))
        (0 until list.length()).mapNotNull { i ->
            val item = list.optJSONObject(i) ?: return@mapNotNull null
            val a = item.optString("a", "")
            val k = item.optString("k", "")
            val r = item.optString("r", "")
            if (a.isBlank() || k.isBlank()) null else Notifier.Dhikr(a, k, r)
        }
    } catch (_: Exception) { emptyList() }

    fun save(ctx: Context, raw: String): Boolean {
      return try {
        if (raw.length > 500_000) return false
        val arr = JSONArray(raw)
        if (arr.length() > MAX_ITEMS) return false
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: return false
            val arabic = item.optString("a", "")
            val kurdish = item.optString("k", "")
            val reference = item.optString("r", "")
            if (arabic.isBlank() || kurdish.isBlank() || arabic.length > 1200 ||
                kurdish.length > 1200 || reference.length > 400) return false
        }
        val saved = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).commit()
        if (saved) ctx.getSharedPreferences("zikr_state", Context.MODE_PRIVATE)
            .edit().remove("queue").apply()
        saved
      } catch (_: Exception) { false }
    }
}
