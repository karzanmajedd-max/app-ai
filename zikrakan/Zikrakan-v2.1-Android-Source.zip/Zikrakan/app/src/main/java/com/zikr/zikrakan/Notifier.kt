package com.zikr.zikrakan

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.widget.RemoteViews
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import org.json.JSONArray

/**
 * ئەگەر «پیشاندان لەسەر ئەپەکانی دیکە» ڕێگەپێدراو بێت ← کارتی زیکر لەسەر شاشە (Overlay)
 * دەنا ← نۆتیکیشنی Heads-up
 */
object Notifier {
    private const val NOTIF_ID = 2001
    private const val STATE = "zikr_state"
    private const val QUIET_CH = "zikr_quiet_v1"

    class Dhikr(val a: String, val k: String, val r: String)

    fun hasPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun hasOverlay(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    private fun loadDhikr(ctx: Context): List<Dhikr> {
        val txt = ctx.assets.open("dhikr.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val arr = JSONArray(txt)
        val defaults = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Dhikr(o.getString("a"), o.getString("k"), o.optString("r", ""))
        }
        return defaults + CustomDhikrStore.load(ctx)
    }

    private fun pickIndex(ctx: Context, size: Int): Int {
        val sp = ctx.getSharedPreferences(STATE, Context.MODE_PRIVATE)
        val queue = (sp.getString("queue", "") ?: "")
            .split(",").filter { it.isNotBlank() }.mapNotNull { it.toIntOrNull() }.filter { it >= 0 && it < size }.toMutableList()
        val last = sp.getInt("last", -1)
        if (queue.isEmpty()) {
            queue.addAll((0 until size).shuffled())
            if (queue.size > 1 && queue[0] == last) {
                val t = queue[0]; queue[0] = queue[1]; queue[1] = t
            }
        }
        val idx = queue.removeAt(0)
        sp.edit().putString("queue", queue.joinToString(",")).putInt("last", idx).apply()
        return idx
    }

    fun channelId(sound: Boolean, vibrate: Boolean): String =
        "zikr_" + (if (sound) "s" else "q") + (if (vibrate) "v" else "n") + "_v1"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val soundUri = Uri.parse("android.resource://" + ctx.packageName + "/" + R.raw.zikr_golden_chime)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        for (sound in listOf(true, false)) {
            for (vib in listOf(true, false)) {
                val name = "زیکرەکان — " + (if (sound) "بە دەنگ" else "بێ دەنگ") +
                    " / " + (if (vib) "بە لەرزین" else "بێ لەرزین")
                val ch = NotificationChannel(channelId(sound, vib), name, NotificationManager.IMPORTANCE_HIGH)
                ch.description = "یادخستنەوەی زیکرەکان (Heads-up)"
                ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                ch.enableVibration(vib)
                if (vib) ch.vibrationPattern = longArrayOf(0, 250, 150, 250)
                if (sound) ch.setSound(soundUri, attrs) else ch.setSound(null, null)
                nm.createNotificationChannel(ch)
            }
        }
        // کەناڵی بێدەنگ: کاتێک کارتی Overlay پیشان دراوە، تەنیا لە لیستی نۆتیکیشنەکان دەمێنێتەوە
        val quiet = NotificationChannel(QUIET_CH, "زیکرەکان — تۆمار", NotificationManager.IMPORTANCE_LOW)
        quiet.setSound(null, null)
        quiet.enableVibration(false)
        nm.createNotificationChannel(quiet)
    }

    private fun dismissIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 9,
        Intent(ctx, DismissReceiver::class.java).setAction("com.zikr.zikrakan.DISMISS"),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    /** The system constrains collapsed/head-up notification height. The expanded view is fuller. */
    private fun customView(ctx: Context, layout: Int, d: Dhikr): RemoteViews =
        RemoteViews(ctx.packageName, layout).apply {
            setTextViewText(R.id.notification_arabic, d.a)
            setTextViewText(R.id.notification_kurdish, d.k)
            if (layout == R.layout.notification_zikr_expanded) {
                setTextViewText(R.id.notification_reference, d.r)
                setViewVisibility(R.id.notification_reference,
                    if (d.r.isBlank()) android.view.View.GONE else android.view.View.VISIBLE)
            }
        }

    private fun post(ctx: Context, channel: String, d: Dhikr) {
        if (!hasPermission(ctx)) return
        val dismiss = dismissIntent(ctx)
        val n = Notification.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_zikr)
            .setContentTitle("زیکرەکان — " + d.a)
            .setContentText(d.k)
            .setCategory(Notification.CATEGORY_REMINDER)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(dismiss) // Tap dismisses: it never opens the app.
            .setCustomContentView(customView(ctx, R.layout.notification_zikr_compact, d))
            .setCustomHeadsUpContentView(customView(ctx, R.layout.notification_zikr_compact, d))
            .setCustomBigContentView(customView(ctx, R.layout.notification_zikr_expanded, d))
            .setShowWhen(true)
            .setWhen(System.currentTimeMillis())
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
    }

    private fun cancel(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
    }

    /** دەنگ و لەرزین بۆ کاتی Overlay (لەبەر ئەوەی کەناڵی نۆتیکیشن بێدەنگە) */
    private fun alert(ctx: Context, p: ZikrPrefs) {
        try {
            if (p.sound) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val mp = MediaPlayer.create(ctx, R.raw.zikr_golden_chime, attrs, AudioManager.AUDIO_SESSION_ID_GENERATE)
                mp?.setOnCompletionListener { it.release() }
                mp?.start()
            }
            if (p.vibrate) {
                @Suppress("DEPRECATION")
                val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 250, 150, 250), -1))
            }
        } catch (e: Exception) {
        }
    }

    fun show(ctx: Context, p: ZikrPrefs) {
        val app = ctx.applicationContext
        val list = loadDhikr(app)
        if (list.isEmpty()) return
        val d = list[pickIndex(app, list.size)]
        ensureChannels(app)

        if (hasOverlay(app)) {
            Overlay.show(
                app, d,
                onFail = { post(app, channelId(p.sound, p.vibrate), d) },
                onClosed = { cancel(app) }
            )
            alert(app, p)
            post(app, QUIET_CH, d)
        } else {
            post(app, channelId(p.sound, p.vibrate), d)
        }
    }
}
