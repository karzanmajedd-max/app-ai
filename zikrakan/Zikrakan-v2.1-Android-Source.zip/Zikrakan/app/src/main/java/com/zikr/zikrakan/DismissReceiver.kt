package com.zikr.zikrakan

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Clear a displayed notification without launching the app. */
class DismissReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        context.getSystemService(NotificationManager::class.java).cancel(2001)
    }
}
