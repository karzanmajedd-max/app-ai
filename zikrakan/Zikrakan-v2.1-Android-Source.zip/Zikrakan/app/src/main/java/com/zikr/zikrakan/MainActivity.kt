package com.zikr.zikrakan

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val bg = 0xFF061410.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        root.setBackgroundColor(bg)
        root.fitsSystemWindows = true

        web = WebView(this)
        web.setBackgroundColor(bg)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")

        root.addView(
            web,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        setContentView(root)
        web.loadUrl("file:///android_asset/index.html")
        Notifier.ensureChannels(this)
    }

    override fun onResume() {
        super.onResume()
        Scheduler.schedule(this)
        setupNext()
    }

    /** ڕێپێدانەکان یەک بە یەک دەخوازرێن (هەر یەکە تەنیا جارێک) */
    private fun setupNext() {
        val sp = getSharedPreferences("zikr_state", MODE_PRIVATE)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !sp.getBoolean("asked_notif", false)
        ) {
            sp.edit().putBoolean("asked_notif", true).apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
            return
        }

        if (!Settings.canDrawOverlays(this) && !sp.getBoolean("asked_overlay", false)) {
            sp.edit().putBoolean("asked_overlay", true).apply()
            AlertDialog.Builder(this)
                .setTitle("زیکر لەسەر شاشە")
                .setMessage("بۆ ئەوەی زیکرەکان وەک کارتێک لەسەر هەموو ئەپەکان دەربکەون، «پیشاندان لەسەر ئەپەکانی دیکە» چالاک بکە.")
                .setPositiveButton("باشە") { _, _ ->
                    try {
                        startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                        )
                    } catch (e: Exception) {
                    }
                }
                .setNegativeButton("دواتر", null)
                .show()
            return
        }

        if (Build.VERSION.SDK_INT >= 31 && !Scheduler.canExact(this) && !sp.getBoolean("asked_exact", false)) {
            sp.edit().putBoolean("asked_exact", true).apply()
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
            }
            return
        }

        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !sp.getBoolean("asked_batt", false)) {
            sp.edit().putBoolean("asked_batt", true).apply()
            AlertDialog.Builder(this)
                .setTitle("نۆتیکیشنی بەکاتی")
                .setMessage("بۆ ئەوەی زیکرەکان لە کاتی خۆیان بێن، ئەپەکە لە سنووردارکردنی باتری دەربکە.")
                .setPositiveButton("باشە") { _, _ ->
                    try {
                        startActivity(
                            Intent(
                                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                Uri.parse("package:$packageName")
                            )
                        )
                    } catch (e: Exception) {
                        try {
                            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                        } catch (e2: Exception) {
                        }
                    }
                }
                .setNegativeButton("دواتر", null)
                .show()
        }
    }

    private fun openNotificationSettings() {
        val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        try {
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    /** پردی JavaScript ← Kotlin  (window.Android) */
    inner class Bridge {
        @JavascriptInterface
        fun savePrefs(json: String) {
            ZikrPrefs.saveRaw(applicationContext, json)
            Scheduler.schedule(applicationContext)
        }

        /** Read/write user-entered adhkar on device. Separate from notification schedule preferences. */
        @JavascriptInterface
        fun getCustomDhikr(): String = CustomDhikrStore.raw(applicationContext)

        @JavascriptInterface
        fun saveCustomDhikr(json: String): Boolean =
            CustomDhikrStore.save(applicationContext, json)

        @JavascriptInterface
        fun showTest() {
            if (!Notifier.hasPermission(applicationContext) && !Notifier.hasOverlay(applicationContext)) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "ڕێگە بدە بە نۆتیکیشنەکان", Toast.LENGTH_LONG).show()
                    openNotificationSettings()
                }
                return
            }
            Notifier.show(applicationContext, ZikrPrefs.load(applicationContext))
        }
    }
}
