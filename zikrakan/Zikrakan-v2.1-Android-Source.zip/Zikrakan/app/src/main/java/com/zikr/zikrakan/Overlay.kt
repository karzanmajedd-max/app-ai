package com.zikr.zikrakan

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** کارتی زیکر لەسەر هەموو ئەپەکان — بە دەست لێدان دادەخرێت */
object Overlay {
    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var current: View? = null
    private val auto = Runnable { dismiss() }
    private var onDismiss: (() -> Unit)? = null

    private fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun show(ctx: Context, d: Notifier.Dhikr, onFail: () -> Unit, onClosed: () -> Unit) {
        val app = ctx.applicationContext
        handler.post {
            try {
                dismiss()
                val manager = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val view = build(app, d)
                val width = minOf(dp(app, 450), app.resources.displayMetrics.widthPixels - dp(app, 20))
                val lp = WindowManager.LayoutParams(
                    width,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                )
                lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                lp.y = dp(app, 36)
                view.translationY = -dp(app, 220).toFloat()
                view.alpha = 0f
                manager.addView(view, lp)
                view.animate().translationY(0f).alpha(1f).setDuration(350).start()
                wm = manager
                current = view
                onDismiss = onClosed
                handler.postDelayed(auto, 60_000) // پاراستن: دوای ١ خولەک خۆی دادەخرێت
            } catch (e: Exception) {
                current = null
                onFail()
            }
        }
    }

    fun dismiss() {
        handler.removeCallbacks(auto)
        val v = current
        if (v != null) {
            try {
                wm?.removeView(v)
            } catch (e: Exception) {
            }
        }
        current = null
        val cb = onDismiss
        onDismiss = null
        cb?.invoke()
    }

    private fun build(ctx: Context, d: Notifier.Dhikr): View {
        val ivory = 0xFFFFF1D9.toInt()
        val gold = 0xFFD8B978.toInt()
        val reg = Typeface.createFromAsset(ctx.assets, "NRT-Reg.ttf")
        val bold = Typeface.createFromAsset(ctx.assets, "NRT-Bd.ttf")

        fun tv(text: String, sp: Float, color: Int, tf: Typeface?): TextView = TextView(ctx).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            setTextColor(color)
            if (tf != null) typeface = tf
            gravity = Gravity.CENTER
        }

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(ctx, 19), dp(ctx, 18), dp(ctx, 19), dp(ctx, 20))
            background = GradientDrawable().apply {
                setColor(0xFF2B3D35.toInt())
                cornerRadius = dp(ctx, 23).toFloat()
                setStroke(dp(ctx, 1), 0xFF8C805E.toInt())
            }
            elevation = dp(ctx, 12).toFloat()
        }

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val icon = tv("\u263E", 29f, gold, null).apply {
            background = GradientDrawable().apply {
                setColor(0xFF12362B.toInt())
                cornerRadius = dp(ctx, 11).toFloat()
            }
        }
        header.addView(icon, LinearLayout.LayoutParams(dp(ctx, 44), dp(ctx, 44)))
        val title = tv("زیکرەکان", 17f, ivory, bold).apply { gravity = Gravity.CENTER_VERTICAL or Gravity.START }
        header.addView(
            title,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(ctx, 10)
            }
        )
        header.addView(tv("ئێستا", 13f, 0xFFC8D1C4.toInt(), reg))
        root.addView(header)

        val arabic = tv(d.a, 27f, ivory, Typeface.create(Typeface.DEFAULT, Typeface.BOLD)).apply {
            setLineSpacing(0f, 1.35f)
        }
        root.addView(
            arabic,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(ctx, 22); bottomMargin = dp(ctx, 18) }
        )
        val kurdish = tv(d.k, 17f, ivory, reg).apply { setLineSpacing(0f, 1.4f) }
        root.addView(
            kurdish,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )
        if (d.r.isNotBlank()) {
            root.addView(
                tv(d.r, 12f, gold, reg),
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = dp(ctx, 4) }
            )
        }
        root.addView(
            tv("دەست لێبدە بۆ داخستن", 13f, 0xFFDBC68E.toInt(), reg),
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(ctx, 21) }
        )

        root.setOnClickListener { dismiss() }
        return root
    }
}
