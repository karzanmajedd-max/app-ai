package com.zikr.zikrakan

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val p = ZikrPrefs.load(context)
        if (p.enabled) Notifier.show(context, p)
        Scheduler.schedule(context) // کاتی دواتر ڕێکبخە
    }
}
