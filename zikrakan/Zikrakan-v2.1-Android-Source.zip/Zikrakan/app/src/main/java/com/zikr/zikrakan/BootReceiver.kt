package com.zikr.zikrakan

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** دوای ڕیستارتکردن / گۆڕینی کات، ئالارمەکان دووبارە دادەنرێنەوە */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Scheduler.schedule(context)
    }
}
