package com.zikr.zikrakan

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import org.json.JSONArray

/** نۆتیکیشنی Heads-up ـی زیکرەکان دروست دەکات */
object Notifier {
    private const val NOTIF_ID = 2001
    private const val STATE = "zikr_state"

    class Dhikr(val a: String, val k: String, val r: String)

    fun hasPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun loadDhikr(ctx: Context): List<Dhikr> {
        val txt = ctx.assets.open("dhikr.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val arr = JSONArray(txt)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Dhikr(o.getString("a"), o.getString("k"), o.optString("r", ""))
        }
    }

    /** هەموو زیکرەکان بە شێوەی تێکەڵ دەهێنرێن، بێ دووبارەبوونەوەی یەک لە دوای یەک */
    private fun pickIndex(ctx: Context, size: Int): Int {
        val sp = ctx.getSharedPreferences(STATE, Context.MODE_PRIVATE)
        val queue = (sp.getString("queue", "") ?: "")
            .split(",").filter { it.isNotBlank() }.map { it.toInt() }.filter { it < size }.toMutableList()
        val last = sp.getInt("last", -1)
        if (queue.isEmpty()) {
            queue.addAll((0 until size).shuffled())
            if (queue.size > 1 && queue[0] == last) {
                val t = queue[0]; queue[0] = queue[1]; queue[1] = t
            }
        }
        val idx = queue.removeAt(0)
        sp.edit().putString("queue", queue.joinToString(",")).putInt("last", idx).apply()
        return idx
    }

    fun channelId(sound: Boolean, vibrate: Boolean): String =
        "zikr_" + (if (sound) "s" else "q") + (if (vibrate) "v" else "n") + "_v1"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val soundUri = Uri.parse("android.resource://" + ctx.packageName + "/" + R.raw.zikr_golden_chime)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        for (sound in listOf(true, false)) {
            for (vib in listOf(true, false)) {
                val name = "زیکرەکان — " + (if (sound) "بە دەنگ" else "بێ دەنگ") +
                    " / " + (if (vib) "بە لەرزین" else "بێ لەرزین")
                // IMPORTANCE_HIGH = Heads-up (بانەر لەسەر هەموو ئەپەکان)
                val ch = NotificationChannel(channelId(sound, vib), name, NotificationManager.IMPORTANCE_HIGH)
                ch.description = "یادخستنەوەی زیکرەکان"
                ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                ch.enableVibration(vib)
                if (vib) ch.vibrationPattern = longArrayOf(0, 250, 150, 250)
                if (sound) ch.setSound(soundUri, attrs) else ch.setSound(null, null)
                nm.createNotificationChannel(ch)
            }
        }
    }

    fun show(ctx: Context, p: ZikrPrefs) {
        if (!hasPermission(ctx)) return
        ensureChannels(ctx)
        val list = loadDhikr(ctx)
        if (list.isEmpty()) return
        val d = list[pickIndex(ctx, list.size)]

        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val big = if (d.r.isNotBlank()) d.k + "\n" + d.r else d.k

        val n = Notification.Builder(ctx, channelId(p.sound, p.vibrate))
            .setSmallIcon(R.drawable.ic_stat_zikr)
            .setContentTitle(d.a)
            .setContentText(d.k)
            .setStyle(Notification.BigTextStyle().bigText(big))
            .setCategory(Notification.CATEGORY_REMINDER)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(open)
            .setShowWhen(true)
            .setWhen(System.currentTimeMillis())
            .build()

        ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
    }
}
