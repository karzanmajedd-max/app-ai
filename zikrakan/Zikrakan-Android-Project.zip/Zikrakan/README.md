# زیکرەکان — Heads-up Notification

## چۆن APK دروست بکەیت
1. **Android Studio** (Koala یان نوێتر) بکەرەوە ← `Open` ← فۆلدەری `Zikrakan`.
2. ڕێگە بدە Gradle Sync تەواو ببێت (ئینتەرنێت پێویستە).
3. `Build ← Build Bundle(s)/APK(s) ← Build APK(s)`.
4. APK ـەکە لێرە دەبێت: `app/build/outputs/apk/debug/app-debug.apk`

> ئەگەر ئەپە کۆنەکە (`com.zikr.zikrakan`) دامەزراوە و واژۆی جیاوازە، سەرەتا بیسڕەوە.

## ئەوەی گۆڕدرا
- `index.html` — تەنیا ٤ گۆڕانکاری بچووک: ڕێکخستنەکان دەنێردرێن بۆ Kotlin (`Android.savePrefs`)، دوگمەی «نموونە» نۆتیکیشنی ڕاستەقینە پیشان دەدات، و نۆتیکیشنی ساختەی ناو ئەپەکە ناچالاک دەبێت.
- `dhikr.json` — ١٧ زیکرەکە (هەمان ناوەڕۆکی index.html).
- `Scheduler.kt` — کاتی داهاتوو دەژمێرێت (هەر چەند خولەک / کاتە دیاریکراوەکان) و `AlarmManager` ڕێکدەخات.
- `Notifier.kt` — نۆتیکیشنی `IMPORTANCE_HIGH` (Heads-up)، دەنگ و لەرزین بە گوێرەی ڕێکخستن.
- `BootReceiver.kt` — دوای ڕیستارت ئالارمەکان دووبارە دادەنێت.

## گرنگ لەسەر مۆبایلە چینییەکان (Xiaomi / Oppo / Vivo / Samsung)
لە ڕێکخستنی ئەپەکە:
- **Notifications ← Floating / Pop-up notifications** چالاک بکە
- **Autostart** چالاک بکە
- **Battery ← No restrictions**

بەبێ ئەمانە سیستەم دەتوانێت ئالارمەکان ڕابگرێت یان بانەرەکە پیشان نەدات.
